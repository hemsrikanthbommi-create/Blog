
const express=require('express');
const app=express();
app.use(express.json());
app.use('/api/posts',require('./routes/postRoutes'));
app.use('/api/comments',require('./routes/commentRoutes'));
app.listen(5000);
