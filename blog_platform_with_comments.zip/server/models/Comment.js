
const mongoose=require('mongoose');
module.exports=mongoose.model('Comment',new mongoose.Schema({
 postId:String,user:String,text:String
}));
