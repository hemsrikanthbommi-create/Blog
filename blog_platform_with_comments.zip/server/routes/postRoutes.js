
const router=require('express').Router();
router.get('/',(req,res)=>res.json([]));
router.post('/',(req,res)=>res.json({message:'Post Created'}));
module.exports=router;
