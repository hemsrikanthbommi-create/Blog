
import React from 'react';
export default function App(){
 return <h1>Blog Platform</h1>;
}
